# 🏗️ Mentor Architecture

---

## 🧩 Структура слоёв

```text
Mentor Architecture

├── Discovery Layer
│   └── system_probe (ENG-0001)
│   └── interface_discovery (ENG-0002)
│   └── program_discovery_by_pattern (ENG-0012)
│
├── Learning Layer
│   └── documentation_parser (ENG-0003)
│   └── skill_schema (ENG-0004)
│   └── test_runner (ENG-0008)
│   └── confidence_calculator (ENG-0009)
│   └── sandbox_execution (ENG-0007)
│
├── Storage Layer
│   └── skill_persistence (ENG-0005)
│   └── skill_search (ENG-0006)
│
└── Interaction Layer
    └── agent_registry (ENG-0010)
    └── skill_context_builder (ENG-0011)
```
