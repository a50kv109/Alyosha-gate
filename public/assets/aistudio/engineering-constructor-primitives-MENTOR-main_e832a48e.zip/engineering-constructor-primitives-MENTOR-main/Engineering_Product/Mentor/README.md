# 🧠 Mentor — Universal Skill Module

--------------------------------------------------

**Type:**
Engineering Product

**Built From:**
Engineering Constructor Primitives (ECP)

**Name:**
Mentor

**Purpose:**
Accelerate learning by composing and applying capabilities provided by Engineering Skeleton.

--------------------------------------------------


## 📋 Overview

Mentor — универсальный модуль для обучения AI-агентов работе с инструментами в произвольной среде.

Mentor не знает конкретной предметной области.  
Mentor знает, как превращать инструменты в формализованные навыки.

---

## 🎯 Mission

**Mentor** превращает программы в структурированные навыки, которые агенты могут использовать многократно.

---

## 🏗️ Architecture

Mentor состоит из 4-х слоёв:

1. **Discovery** — обнаружение инструментов
2. **Learning** — изучение инструментов
3. **Storage** — хранение навыков
4. **Interaction** — взаимодействие с агентами

---

## 🔗 Built on Engineering Skeleton

Mentor использует 12 ECPs из Skeleton:

| Skeleton | Mentor Layer |
|----------|--------------|
| ENG-0001, ENG-0002, ENG-0012 | Discovery |
| ENG-0003, ENG-0004, ENG-0007, ENG-0008, ENG-0009 | Learning |
| ENG-0005, ENG-0006 | Storage |
| ENG-0010, ENG-0011 | Interaction |

---

## 📂 Structure

```
Engineering_Product/Mentor/
├── README.md           (этот файл)
├── MISSION.md          (зачем Mentor существует)
├── ARCHITECTURE.md     (модульная архитектура)
├── WORKFLOW.md         (сценарии работы)
├── COMPOSITION.md      (использование Skeleton)
├── INTERFACES.md       (внешние интерфейсы)
└── BUILD.md            (сборка и запуск)
```
