# 🔄 Mentor Workflows

---

## 1️⃣ Сценарий 1: Изучение новой программы

```text
User/Agent
    │
    │ "Изучи программу X"
    ↓
Discovery → system_probe → interface_discovery
    ↓
Learning → documentation_parser → test_runner → confidence_calculator
    ↓
Storage → skill_schema → skill_persistence
    ↓
Mentor → "Навык сохранён"
```

---

## 2️⃣ Сценарий 2: Поиск навыка

```text
Agent
    │
    │ "Найди навык для задачи Y"
    ↓
Storage → skill_search → skill_persistence
    ↓
Interaction → skill_context_builder → agent_registry
    ↓
Mentor → "Навык адаптирован"
```
