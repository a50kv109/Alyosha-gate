# Engineering Skeleton

--------------------------------------------------

**Type:**
Engineering Constructor Primitive (ECP) Library

**Name:**
Engineering Skeleton

**Purpose:**
Provide reusable engineering constructor primitives for building Engineering Products.

--------------------------------------------------


```text
Status:
Release Candidate 1

Architecture:
Frozen

Engineering Model:
Frozen

Future changes:
Documentation fixes only
Bug fixes only
```

**Универсальная инженерная грамматика.**

Этот каталог содержит Engineering Constructor Primitives (ECP). Они абстрагированы от конкретного конечного продукта и могут быть использованы как конструктор для сборки систем (таких как Universal Mentor, BOOK-NAV, SOL-CAD). 

Основная задача Skeleton — зафиксировать стабильную архитектурную грамматику (сущности, инварианты, решения), которая разделяется всеми продуктами.

## Принципы проектирования

- **Абстракция от предметной области:** ECPs не содержат бизнес-логики.
- **Стабильная идентификация:** Каждая сущность, инвариант и решение имеет глобальный уникальный идентификатор (например, `ENG-0001`, `INV-0002`). Это позволяет агентам и разработчикам ссылаться на концепции с нулевой двусмысленностью.
- **Композируемость:** Продукты собираются путем связывания ECPs (см. [Architecture Graph](./graph/README.md)).

## Структура каталогов

| Каталог | Назначение |
|---------|------------|
| 🧱 [`/entities`](./entities/) | Базовые сущности системы (`ENG-XXXX`). Основные концептуальные узлы. |
| 🕸️ [`/graph`](./graph/README.md) | Структурные архитектурные связи между сущностями. Топология ECPs. |
| 🧠 [`/rationale`](./rationale/README.md) | Инженерная мотивация и обоснование сущностей. |
| 🛡️ [`/invariants`](./invariants/) | Ограничения, аксиомы и правила (`INV-XXXX`). Условия, которые никогда не должны нарушаться. |
| 🔄 [`/lifecycle`](./lifecycle/README.md) | Модели жизненных циклов и состояний сущностей. |
| ⚖️ [`/decisions`](./decisions/) | Реестр архитектурных решений (`ADR-XXXX`). Обоснования выбора пути развития. |
| 🤝 [`/interactions`](./interactions/README.md) | Сценарии взаимодействия (`SCN-XXXX`). Поведенческие контракты. |
| 📦 [`/classification`](./classification/README.md) | Разделение архитектуры на слои CORE и DOMAIN. |
| 🔗 [`/dependencies`](./dependencies/README.md) | Формальные требования компонентов к среде. |
| ⚡ [`/capabilities`](./capabilities/README.md) | Спецификация навыков и ограничений (`CAP-XXXX`). |

## Как использовать Skeleton

1. Найдите необходимую сущность в реестре `/entities`.
2. Проверьте её инварианты в `/invariants`.
3. При необходимости расширения, создайте новый `ENG-XXXX` и опишите мотивацию в `ADR`.
4. Соберите итоговый `Engineering_Product`, импортируя необходимые компоненты.

---
*Все файлы внутри этих каталогов должны следовать единым правилам разметки из [ENGINEERING_STANDARDS.md](../../docs/ENGINEERING_STANDARDS.md).*
