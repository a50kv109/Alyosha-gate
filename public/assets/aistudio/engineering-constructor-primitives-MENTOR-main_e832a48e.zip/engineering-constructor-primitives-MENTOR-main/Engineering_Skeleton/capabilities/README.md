# 🧩 Engineering Skeleton — Capabilities
## 📊 Инженерные способности сущностей

---

**ВЕРСИЯ:** 1.0
**СТАТУС:** COMPLETE
**ОСНОВАНИЕ:** Engineering Entities (ENG-0001 — ENG-0012)

---

## 📋 НАЗНАЧЕНИЕ КАТАЛОГА

Каталог `capabilities/` содержит **формальное описание инженерных способностей** каждой сущности.

Capability — это **что сущность умеет делать**.

Она отвечает на вопросы:

- Что умеет делать сущность?
- Что она обязана делать?
- Что она принципиально не делает?
- Какие результаты производит?
- Какие ограничения имеет?

---

## 📊 СПИСОК CAPABILITIES

| ID | Название | Сущность | Статус |
|----|----------|----------|--------|
| CAP-0001 | Проверка наличия программы | ENG-0001 | ✅ COMPLETE |
| CAP-0002 | Определение версии программы | ENG-0001 | ✅ COMPLETE |
| CAP-0003 | Определение пути к программе | ENG-0001 | ✅ COMPLETE |
| CAP-0004 | Определение доступных интерфейсов | ENG-0002 | ✅ COMPLETE |
| CAP-0005 | Классификация интерфейсов | ENG-0002 | ✅ COMPLETE |
| CAP-0006 | Извлечение структурированной информации | ENG-0003 | ✅ COMPLETE |
| CAP-0007 | Извлечение параметров из --help | ENG-0003 | ✅ COMPLETE |
| CAP-0008 | Извлечение примеров из man | ENG-0003 | ✅ COMPLETE |
| CAP-0009 | Формализация навыка | ENG-0004 | ✅ COMPLETE |
| CAP-0010 | Валидация структуры навыка | ENG-0004 | ✅ COMPLETE |
| CAP-0011 | Сериализация навыка | ENG-0004 | ✅ COMPLETE |
| CAP-0012 | Сохранение навыка | ENG-0005 | ✅ COMPLETE |
| CAP-0013 | Загрузка навыка по ID | ENG-0005 | ✅ COMPLETE |
| CAP-0014 | Список всех навыков | ENG-0005 | ✅ COMPLETE |
| CAP-0015 | Поиск навыка по запросу | ENG-0006 | ✅ COMPLETE |
| CAP-0016 | Сортировка результатов | ENG-0006 | ✅ COMPLETE |
| CAP-0017 | Фильтрация результатов | ENG-0006 | ✅ COMPLETE |
| CAP-0018 | Безопасное выполнение команд | ENG-0007 | ✅ COMPLETE |
| CAP-0019 | Ограничение времени выполнения | ENG-0007 | ✅ COMPLETE |
| CAP-0020 | Захват stdout и stderr | ENG-0007 | ✅ COMPLETE |
| CAP-0021 | Выполнение набора тестов | ENG-0008 | ✅ COMPLETE |
| CAP-0022 | Агрегация результатов тестов | ENG-0008 | ✅ COMPLETE |
| CAP-0023 | Расчёт успешности выполнения | ENG-0008 | ✅ COMPLETE |
| CAP-0024 | Расчёт уровня уверенности | ENG-0009 | ✅ COMPLETE |
| CAP-0025 | Агрегация компонентов уверенности | ENG-0009 | ✅ COMPLETE |
| CAP-0026 | Регистрация агентов | ENG-0010 | ✅ COMPLETE |
| CAP-0027 | Управление подписками | ENG-0010 | ✅ COMPLETE |
| CAP-0028 | Адаптация навыка под контекст | ENG-0011 | ✅ COMPLETE |
| CAP-0029 | Построение команды | ENG-0011 | ✅ COMPLETE |
| CAP-0030 | Поиск программ по шаблону | ENG-0012 | ✅ COMPLETE |
| CAP-0031 | Обнаружение программ в системе | ENG-0012 | ✅ COMPLETE |

---

## 📋 ШАБЛОН СПЕЦИФИКАЦИИ CAPABILITY

```yaml
---
id: CAP-XXXX
name: [название]
entity: ENG-XXXX

description: |
  [полное описание способности]

input: |
  [что принимает на вход]

output: |
  [что возвращает]

obligations: |
  [что обязана делать]

limitations: |
  [что принципиально не делает]

produces: |
  [какие результаты производит]

requires: |
  [что требуется для работы]

invariants_enforced: |
  [какие инварианты обеспечивает]

confidence: Fact | Strong Inference | Hypothesis
source: [откуда взято знание]
```

---

## 📋 СПЕЦИФИКАЦИИ CAPABILITIES

### CAP-0001: Проверка наличия программы

```yaml
---
id: CAP-0001
name: "Проверка наличия программы"
entity: ENG-0001

description: |
  Проверяет, существует ли программа в системе по её имени.
  Использует стандартные пути поиска (PATH).

input: |
  - program_name: string — имя программы

output: |
  - found: bool — true, если программа найдена
  - path: string — путь к программе (если найдена)

obligations: |
  - Возвращать корректный результат проверки
  - Не иметь побочных эффектов

limitations: |
  - Работает только в Linux-системе
  - Не определяет интерфейсы программы
  - Не выполняет программы

produces: |
  - DiscoveryResult: {found: bool, path: string}

requires: |
  - Доступ к файловой системе (PATH)

invariants_enforced: |
  - INV-0001 (detection_before_use)

confidence: Fact
source: "Mentor Chat — Discovery Engine Design"
```

---

### CAP-0002: Определение версии программы

```yaml
---
id: CAP-0002
name: "Определение версии программы"
entity: ENG-0001

description: |
  Определяет версию программы путём выполнения `--version` или аналогичной команды.

input: |
  - program_path: string — путь к программе

output: |
  - version: string — версия программы (если определена)

obligations: |
  - Возвращать версию в стандартном формате

limitations: |
  - Не все программы поддерживают `--version`
  - Может возвращать пустую строку

produces: |
  - version: string

requires: |
  - CAP-0001 (проверка наличия программы)

invariants_enforced: |
  - INV-0001 (detection_before_use)

confidence: Fact
source: "Mentor Chat — Discovery Engine Design"
```

---

### CAP-0003: Определение пути к программе

```yaml
---
id: CAP-0003
name: "Определение пути к программе"
entity: ENG-0001

description: |
  Определяет полный путь к программе в файловой системе.

input: |
  - program_name: string — имя программы

output: |
  - path: string — полный путь к программе

obligations: |
  - Возвращать корректный путь
  - Возвращать None, если программа не найдена

limitations: |
  - Работает только в Linux-системе

produces: |
  - path: string | None

requires: |
  - CAP-0001 (проверка наличия программы)

invariants_enforced: |
  - INV-0001 (detection_before_use)

confidence: Fact
source: "Mentor Chat — Discovery Engine Design"
```

---

### CAP-0004: Определение доступных интерфейсов

```yaml
---
id: CAP-0004
name: "Определение доступных интерфейсов"
entity: ENG-0002

description: |
  Определяет, какие интерфейсы доступны у программы.
  Проверяет CLI, API, Python-модуль, man-страницу.

input: |
  - program_name: string — имя программы
  - program_path: string — путь к программе

output: |
  - interfaces: List[Interface] — список доступных интерфейсов

obligations: |
  - Возвращать полный список интерфейсов
  - Корректно определять тип каждого интерфейса

limitations: |
  - Не выполняет программы
  - Не анализирует содержимое интерфейсов

produces: |
  - InterfaceList: [{type: string, entry_point: string}]

requires: |
  - CAP-0001 (проверка наличия программы)
  - CAP-0003 (определение пути)

invariants_enforced: |
  - INV-0001 (detection_before_use)

confidence: Fact
source: "Mentor Chat — Interface Discovery Design"
```

---

### CAP-0005: Классификация интерфейсов

```yaml
---
id: CAP-0005
name: "Классификация интерфейсов"
entity: ENG-0002

description: |
  Классифицирует обнаруженные интерфейсы по типам:
  CLI, API, Python, man.

input: |
  - interface: Interface — интерфейс для классификации

output: |
  - type: string — тип интерфейса

obligations: |
  - Корректно классифицировать все известные типы

limitations: |
  - Не поддерживает все возможные типы интерфейсов

produces: |
  - type: string

requires: |
  - CAP-0004 (определение доступных интерфейсов)

invariants_enforced: |
  - INV-0001 (detection_before_use)

confidence: Fact
source: "Mentor Chat — Interface Discovery Design"
```

---

### CAP-0006: Извлечение структурированной информации

```yaml
---
id: CAP-0006
name: "Извлечение структурированной информации"
entity: ENG-0003

description: |
  Извлекает структурированную информацию из текстовой документации.
  Обрабатывает --help, man, README.

input: |
  - text: string — текст документации
  - source_type: string — тип источника (help, man, readme)

output: |
  - result: DocumentationResult — структурированная информация

obligations: |
  - Извлекать структурированную информацию
  - Обрабатывать различные форматы документации

limitations: |
  - Не проверяет корректность извлечённой информации
  - Не выполняет программы

produces: |
  - DocumentationResult: {parameters: Dict, examples: List, limitations: List}

requires: |
  - CAP-0004 (определение доступных интерфейсов)

invariants_enforced: |
  - INV-0003 (reproducible_description)

confidence: Fact
source: "Mentor Chat — Learning Engine Design"
```

---

### CAP-0007: Извлечение параметров из --help

```yaml
---
id: CAP-0007
name: "Извлечение параметров из --help"
entity: ENG-0003

description: |
  Извлекает параметры из вывода `--help`.
  Использует регулярные выражения для поиска.

input: |
  - help_text: string — вывод --help

output: |
  - parameters: Dict — словарь параметров и их описаний

obligations: |
  - Извлекать все параметры из текста

limitations: |
  - Зависит от формата --help

produces: |
  - parameters: Dict

requires: |
  - CAP-0006 (извлечение структурированной информации)

invariants_enforced: |
  - INV-0003 (reproducible_description)

confidence: Fact
source: "Mentor Chat — Learning Engine Design"
```

---

### CAP-0008: Извлечение примеров из man

```yaml
---
id: CAP-0008
name: "Извлечение примеров из man"
entity: ENG-0003

description: |
  Извлекает примеры использования из man-страницы.
  Ищет секции "EXAMPLE" или "EXAMPLES".

input: |
  - man_text: string — текст man-страницы

output: |
  - examples: List — список примеров использования

obligations: |
  - Извлекать все примеры из текста

limitations: |
  - Не все man-страницы содержат примеры

produces: |
  - examples: List

requires: |
  - CAP-0006 (извлечение структурированной информации)

invariants_enforced: |
  - INV-0003 (reproducible_description)

confidence: Fact
source: "Mentor Chat — Learning Engine Design"
```

---

### CAP-0009: Формализация навыка

```yaml
---
id: CAP-0009
name: "Формализация навыка"
entity: ENG-0004

description: |
  Создаёт структурированный объект навыка из полученных данных.
  Использует единую схему для всех навыков.

input: |
  - name: string
  - description: string
  - parameters: Dict
  - examples: List
  - limitations: List

output: |
  - skill: Skill — структурированный навык

obligations: |
  - Обеспечивать единый формат для всех навыков
  - Валидировать все обязательные поля

limitations: |
  - Не сохраняет навыки
  - Не выполняет навыки

produces: |
  - Skill: {id: string, name: string, description: string, parameters: Dict, examples: List}

requires: |
  - CAP-0006 (извлечение структурированной информации)

invariants_enforced: |
  - INV-0002 (validation_before_persistence)
  - INV-0003 (reproducible_description)

confidence: Fact
source: "Mentor Chat — Skill Schema Design"
```

---

### CAP-0010: Валидация структуры навыка

```yaml
---
id: CAP-0010
name: "Валидация структуры навыка"
entity: ENG-0004

description: |
  Проверяет, что навык соответствует единой схеме.
  Проверяет наличие всех обязательных полей.

input: |
  - skill: Skill — навык для проверки

output: |
  - valid: bool — true, если навык корректен
  - errors: List — список ошибок валидации

obligations: |
  - Проверять все обязательные поля

limitations: |
  - Не проверяет корректность содержания
  - Не проверяет работоспособность навыка

produces: |
  - ValidationResult: {valid: bool, errors: List}

requires: |
  - CAP-0009 (формализация навыка)

invariants_enforced: |
  - INV-0002 (validation_before_persistence)

confidence: Fact
source: "Mentor Chat — Skill Schema Design"
```

---

### CAP-0011: Сериализация навыка

```yaml
---
id: CAP-0011
name: "Сериализация навыка"
entity: ENG-0004

description: |
  Преобразует навык в JSON-формат для хранения.
  Обеспечивает воспроизводимость сериализации.

input: |
  - skill: Skill — навык для сериализации

output: |
  - json: string — JSON-представление навыка

obligations: |
  - Обеспечивать воспроизводимость сериализации

limitations: |
  - Поддерживает только JSON-формат

produces: |
  - json: string

requires: |
  - CAP-0009 (формализация навыка)

invariants_enforced: |
  - INV-0003 (reproducible_description)

confidence: Fact
source: "Mentor Chat — Skill Schema Design"
```

---

### CAP-0012: Сохранение навыка

```yaml
---
id: CAP-0012
name: "Сохранение навыка"
entity: ENG-0005

description: |
  Сохраняет навык в долговременное хранилище.
  Гарантирует целостность сохранённых данных.

input: |
  - skill: Skill — навык для сохранения

output: |
  - success: bool — true, если сохранение успешно
  - path: string — путь к сохранённому файлу

obligations: |
  - Гарантировать целостность сохранённых данных
  - Обеспечивать воспроизводимость загрузки

limitations: |
  - Работает только с JSON-форматом

produces: |
  - StorageResult: {success: bool, path: string}

requires: |
  - CAP-0011 (сериализация навыка)

invariants_enforced: |
  - INV-0002 (validation_before_persistence)

confidence: Fact
source: "Mentor Chat — Skill Library Design"
```

---

### CAP-0013: Загрузка навыка по ID

```yaml
---
id: CAP-0013
name: "Загрузка навыка по ID"
entity: ENG-0005

description: |
  Загружает навык из хранилища по его уникальному ID.

input: |
  - skill_id: string — ID навыка

output: |
  - skill: Skill | None — загруженный навык

obligations: |
  - Возвращать корректный навык
  - Возвращать None, если навык не найден

limitations: |
  - Работает только с JSON-форматом

produces: |
  - skill: Skill | None

requires: |
  - CAP-0012 (сохранение навыка)

invariants_enforced: |
  - INV-0003 (reproducible_description)

confidence: Fact
source: "Mentor Chat — Skill Library Design"
```

---

### CAP-0014: Список всех навыков

```yaml
---
id: CAP-0014
name: "Список всех навыков"
entity: ENG-0005

description: |
  Возвращает список всех сохранённых навыков.

input: |
  - Нет

output: |
  - skills: List[Skill] — список всех навыков

obligations: |
  - Возвращать полный список навыков

limitations: |
  - Может быть медленным при большом количестве навыков

produces: |
  - skills: List[Skill]

requires: |
  - CAP-0012 (сохранение навыка)

invariants_enforced: |
  - INV-0003 (reproducible_description)

confidence: Fact
source: "Mentor Chat — Skill Library Design"
```

---

### CAP-0015: Поиск навыка по запросу

```yaml
---
id: CAP-0015
name: "Поиск навыка по запросу"
entity: ENG-0006

description: |
  Выполняет поиск навыков по текстовому запросу.
  Использует сопоставление по названию и описанию.

input: |
  - query: string — текст запроса

output: |
  - results: List[Skill] — найденные навыки

obligations: |
  - Возвращать список навыков, соответствующих запросу
  - Сортировать результаты по релевантности

limitations: |
  - Простой текстовый поиск
  - Не использует векторные представления

produces: |
  - SearchResult: {results: List[Skill], total: int}

requires: |
  - CAP-0013 (загрузка навыка по ID)
  - CAP-0014 (список всех навыков)

invariants_enforced: |
  - INV-0003 (reproducible_description)

confidence: Fact
source: "Mentor Chat — Skill Search Design"
```

---

### CAP-0016: Сортировка результатов

```yaml
---
id: CAP-0016
name: "Сортировка результатов"
entity: ENG-0006

description: |
  Сортирует найденные навыки по релевантности запросу.
  Использует простые эвристики.

input: |
  - results: List[Skill] — найденные навыки
  - query: string — исходный запрос

output: |
  - sorted_results: List[Skill] — отсортированные навыки

obligations: |
  - Сортировать по релевантности

limitations: |
  - Простая эвристическая сортировка

produces: |
  - sorted_results: List[Skill]

requires: |
  - CAP-0015 (поиск навыка по запросу)

confidence: Fact
source: "Mentor Chat — Skill Search Design"
```

---

### CAP-0017: Фильтрация результатов

```yaml
---
id: CAP-0017
name: "Фильтрация результатов"
entity: ENG-0006

description: |
  Фильтрует результаты поиска по заданным критериям.
  Например, по типу навыка или уверенности.

input: |
  - results: List[Skill] — результаты поиска
  - filters: Dict — критерии фильтрации

output: |
  - filtered_results: List[Skill] — отфильтрованные навыки

obligations: |
  - Применять все заданные фильтры

limitations: |
  - Поддерживает ограниченный набор фильтров

produces: |
  - filtered_results: List[Skill]

requires: |
  - CAP-0015 (поиск навыка по запросу)

confidence: Fact
source: "Mentor Chat — Skill Search Design"
```

---

### CAP-0018: Безопасное выполнение команд

```yaml
---
id: CAP-0018
name: "Безопасное выполнение команд"
entity: ENG-0007

description: |
  Выполняет команды в изолированной среде.
  Гарантирует, что выполнение не влияет на основную систему.

input: |
  - command: string — команда для выполнения
  - working_dir: string — рабочая директория

output: |
  - result: ExecutionResult — результат выполнения

obligations: |
  - Гарантировать, что выполнение не влияет на основную систему
  - Корректно обрабатывать ошибки выполнения

limitations: |
  - Работает только с CLI-командами

produces: |
  - ExecutionResult: {success: bool, exit_code: int, stdout: string, stderr: string}

requires: |
  - Нет внешних зависимостей

invariants_enforced: |
  - INV-0004 (isolated_execution)

confidence: Fact
source: "Mentor Chat — Practice Engine Design"
```

---

### CAP-0019: Ограничение времени выполнения

```yaml
---
id: CAP-0019
name: "Ограничение времени выполнения"
entity: ENG-0007

description: |
  Ограничивает время выполнения команды.
  Прерывает выполнение по таймауту.

input: |
  - timeout: int — максимальное время выполнения (сек)

output: |
  - timeout: bool — true, если таймаут сработал

obligations: |
  - Прерывать выполнение по таймауту

limitations: |
  - Не гарантирует корректное завершение процесса

produces: |
  - timeout: bool

requires: |
  - CAP-0018 (безопасное выполнение команд)

invariants_enforced: |
  - INV-0004 (isolated_execution)

confidence: Fact
source: "Mentor Chat — Practice Engine Design"
```

---

### CAP-0020: Захват stdout и stderr

```yaml
---
id: CAP-0020
name: "Захват stdout и stderr"
entity: ENG-0007

description: |
  Захватывает стандартный вывод и вывод ошибок выполнения.
  Возвращает их как часть результата.

input: |
  - command: string — команда для выполнения

output: |
  - stdout: string — стандартный вывод
  - stderr: string — вывод ошибок

obligations: |
  - Захватывать весь вывод
  - Возвращать вывод в текстовом формате

limitations: |
  - Ограничен размером вывода

produces: |
  - stdout: string
  - stderr: string

requires: |
  - CAP-0018 (безопасное выполнение команд)

confidence: Fact
source: "Mentor Chat — Practice Engine Design"
```

---

### CAP-0021: Выполнение набора тестов

```yaml
---
id: CAP-0021
name: "Выполнение набора тестов"
entity: ENG-0008

description: |
  Выполняет набор тестовых задач для проверки навыка.
  Агрегирует результаты выполнения.

input: |
  - skill: Skill — навык для тестирования
  - test_cases: List[TestCase] — тестовые задачи

output: |
  - results: List[TestResult] — результаты тестов

obligations: |
  - Выполнять все переданные тесты
  - Возвращать агрегированный результат

limitations: |
  - Не создаёт тесты
  - Не анализирует причины ошибок

produces: |
  - TestResult: {passed: int, failed: int, total: int}

requires: |
  - CAP-0018 (безопасное выполнение команд)
  - CAP-0019 (ограничение времени выполнения)

invariants_enforced: |
  - INV-0002 (validation_before_persistence)
  - INV-0004 (isolated_execution)

confidence: Fact
source: "Mentor Chat — Practice Engine Design"
```

---

### CAP-0022: Агрегация результатов тестов

```yaml
---
id: CAP-0022
name: "Агрегация результатов тестов"
entity: ENG-0008

description: |
  Агрегирует результаты выполнения тестов.
  Подсчитывает количество успешных и неуспешных тестов.

input: |
  - test_results: List[TestResult] — результаты тестов

output: |
  - summary: TestSummary — агрегированный результат

obligations: |
  - Подсчитывать общее количество тестов
  - Подсчитывать количество успешных тестов

limitations: |
  - Не анализирует причины ошибок

produces: |
  - TestSummary: {passed: int, failed: int, total: int, success_rate: float}

requires: |
  - CAP-0021 (выполнение набора тестов)

confidence: Fact
source: "Mentor Chat — Practice Engine Design"
```

---

### CAP-0023: Расчёт успешности выполнения

```yaml
---
id: CAP-0023
name: "Расчёт успешности выполнения"
entity: ENG-0008

description: |
  Рассчитывает процент успешных тестов.
  Используется как базовая метрика уверенности.

input: |
  - summary: TestSummary — агрегированный результат

output: |
  - success_rate: float — процент успешных тестов

obligations: |
  - Возвращать корректный процент

limitations: |
  - Простая метрика

produces: |
  - success_rate: float

requires: |
  - CAP-0022 (агрегация результатов тестов)

confidence: Fact
source: "Mentor Chat — Practice Engine Design"
```

---

### CAP-0024: Расчёт уровня уверенности

```yaml
---
id: CAP-0024
name: "Расчёт уровня уверенности"
entity: ENG-0009

description: |
  Рассчитывает уровень уверенности в навыке на основе результатов тестов.
  Учитывает различные компоненты уверенности.

input: |
  - test_results: List[TestResult] — результаты тестов

output: |
  - confidence: float — уровень уверенности (0-1)

obligations: |
  - Возвращать корректный уровень уверенности
  - Учитывать все компоненты уверенности

limitations: |
  - Зависит от качества тестов

produces: |
  - ConfidenceResult: {score: float, components: Dict}

requires: |
  - CAP-0022 (агрегация результатов тестов)

confidence: Fact
source: "Mentor Chat — Practice Engine Design"
```

---

### CAP-0025: Агрегация компонентов уверенности

```yaml
---
id: CAP-0025
name: "Агрегация компонентов уверенности"
entity: ENG-0009

description: |
  Агрегирует различные компоненты уверенности в единую оценку.
  Учитывает вес каждого компонента.

input: |
  - components: Dict — компоненты уверенности

output: |
  - confidence: float — итоговая уверенность

obligations: |
  - Учитывать все компоненты

limitations: |
  - Веса компонентов фиксированы

produces: |
  - confidence: float

requires: |
  - CAP-0024 (расчёт уровня уверенности)

confidence: Fact
source: "Mentor Chat — Practice Engine Design"
```

---

### CAP-0026: Регистрация агентов

```yaml
---
id: CAP-0026
name: "Регистрация агентов"
entity: ENG-0010

description: |
  Регистрирует агента в системе.
  Сохраняет идентификатор агента и способ уведомления.

input: |
  - agent_id: string — идентификатор агента
  - callback: function — способ уведомления

output: |
  - success: bool — true, если регистрация успешна

obligations: |
  - Сохранять регистрационные данные агентов

limitations: |
  - Не хранит историю взаимодействий

produces: |
  - RegistrationResult: {success: bool, agent_id: string}

requires: |
  - Нет внешних зависимостей

confidence: Fact
source: "Mentor Chat — Agent Bridge Design"
```

---

### CAP-0027: Управление подписками

```yaml
---
id: CAP-0027
name: "Управление подписками"
entity: ENG-0010

description: |
  Управляет подписками агентов на события.
  Уведомляет агентов о событиях.

input: |
  - event: string — тип события
  - data: Any — данные события

output: |
  - notified: int — количество уведомлённых агентов

obligations: |
  - Уведомлять агентов о событиях

limitations: |
  - Не анализирует содержимое сообщений

produces: |
  - notified: int

requires: |
  - CAP-0026 (регистрация агентов)

confidence: Fact
source: "Mentor Chat — Agent Bridge Design"
```

---

### CAP-0028: Адаптация навыка под контекст

```yaml
---
id: CAP-0028
name: "Адаптация навыка под контекст"
entity: ENG-0011

description: |
  Адаптирует универсальный навык под конкретный контекст задачи.
  Добавляет параметры, специфичные для текущей задачи.

input: |
  - skill: Skill — универсальный навык
  - context: Dict — контекст задачи

output: |
  - adapted_skill: Skill — адаптированный навык

obligations: |
  - Возвращать готовую команду для выполнения
  - Учитывать параметры контекста

limitations: |
  - Работает только с CLI-навыками

produces: |
  - ContextResult: {command: string, parameters: Dict}

requires: |
  - CAP-0009 (формализация навыка)

confidence: Strong Inference
source: "Mentor Chat — Context Builder Design"
```

---

### CAP-0029: Построение команды

```yaml
---
id: CAP-0029
name: "Построение команды"
entity: ENG-0011

description: |
  Строит готовую CLI-команду из адаптированного навыка.
  Объединяет программу, параметры и аргументы.

input: |
  - adapted_skill: Skill — адаптированный навык

output: |
  - command: string — готовая CLI-команда

obligations: |
  - Строить корректную CLI-команду

limitations: |
  - Работает только с CLI-навыками

produces: |
  - command: string

requires: |
  - CAP-0028 (адаптация навыка под контекст)

confidence: Strong Inference
source: "Mentor Chat — Context Builder Design"
```

---

### CAP-0030: Поиск программ по шаблону

```yaml
---
id: CAP-0030
name: "Поиск программ по шаблону"
entity: ENG-0012

description: |
  Находит все программы в системе, соответствующие шаблону имени.
  Например, все программы для работы с PDF.

input: |
  - pattern: string — шаблон поиска

output: |
  - programs: List[string] — список найденных программ

obligations: |
  - Возвращать все программы, соответствующие шаблону

limitations: |
  - Работает только в Linux-системе

produces: |
  - programs: List[string]

requires: |
  - CAP-0001 (проверка наличия программы)
  - CAP-0003 (определение пути)

invariants_enforced: |
  - INV-0001 (detection_before_use)

confidence: Fact
source: "Mentor Chat — Discovery Engine Design"
```

---

### CAP-0031: Обнаружение программ в системе

```yaml
---
id: CAP-0031
name: "Обнаружение программ в системе"
entity: ENG-0012

description: |
  Сканирует систему и обнаруживает все доступные программы.
  Использует стандартные пути поиска.

input: |
  - search_paths: List[string] — пути для поиска

output: |
  - programs: List[string] — список обнаруженных программ

obligations: |
  - Сканировать все указанные пути

limitations: |
  - Работает только в Linux-системе

produces: |
  - programs: List[string]

requires: |
  - CAP-0001 (проверка наличия программы)
  - CAP-0003 (определение пути)

invariants_enforced: |
  - INV-0001 (detection_before_use)

confidence: Fact
source: "Mentor Chat — Discovery Engine Design"
```

---

## 📊 СВОДНАЯ СТАТИСТИКА

| Категория | Количество |
|-----------|------------|
| Всего Capabilities | 31 |
| Fact | 29 |
| Strong Inference | 2 |
| Hypothesis | 0 |

---

## 🔗 СВЯЗАННЫЕ РАЗДЕЛЫ

- [Engineering Entities](../entities/README.md) — сущности, владеющие Capabilities
- [Engineering Invariants](../invariants/README.md) — инварианты, обеспечиваемые Capabilities
- [Engineering Dependencies](../dependencies/README.md) — зависимости между сущностями
- [Engineering Graph](../graph/README.md) — граф зависимостей

---

**КОНЕЦ ДОКУМЕНТА**
