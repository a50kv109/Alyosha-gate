# Classification

Правила деления на CORE и DOMAIN.
