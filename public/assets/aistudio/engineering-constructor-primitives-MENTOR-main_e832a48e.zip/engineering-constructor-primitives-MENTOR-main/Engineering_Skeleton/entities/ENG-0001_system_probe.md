# ENG-0001: system_probe

--------------------------------------------------

**Type:**
Engineering Constructor Primitive (ECP)

**Name:**
system_probe

**Identifier:**
ENG-0001

**Purpose:**
`system_probe` — это централизованный Engineering Constructor Primitive (ECP) для верификации доступности исполняемых файлов, бинарников или системных команд в среде выполнения.

--------------------------------------------------

## Description
`system_probe` — это централизованный Engineering Constructor Primitive (ECP) для верификации доступности исполняемых файлов, бинарников или системных команд в среде выполнения.

## Rationale
Агенты не должны слепо полагаться на наличие программ (например, `git`, `python`, `pandoc`). Попытка вызвать отсутствующую программу приводит к необработанным системным ошибкам и нарушает поток выполнения агента. `system_probe` абстрагирует проверки среды, делая среду предсказуемой.

## Interface (Abstract)
- `probe(resource_name: string) -> boolean`
- `locate(resource_name: string) -> string | null`

## Dependencies
- Нет (Root Infrastructure)

## Related Invariants
- [INV-0001](../invariants/INV-0001_detection_before_use.md): discovery_before_use
