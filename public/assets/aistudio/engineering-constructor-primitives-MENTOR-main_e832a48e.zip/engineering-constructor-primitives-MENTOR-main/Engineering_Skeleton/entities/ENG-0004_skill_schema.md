# ENG-0004: skill_schema

--------------------------------------------------

**Type:**
Engineering Constructor Primitive (ECP)

**Name:**
skill_schema

**Identifier:**
ENG-0004

**Purpose:**
`skill_schema` определяет формальную структуру данных (схему), описывающую способность агента взаимодействовать с конкретным инструментом. Схема является сериализуемой и платформонезависимой.

--------------------------------------------------

## Description
`skill_schema` определяет формальную структуру данных (схему), описывающую способность агента взаимодействовать с конкретным инструментом. Схема является сериализуемой и платформонезависимой.

## Rationale
Для того чтобы навыки могли передаваться между агентами, сохраняться в базу данных и переиспользоваться, они должны иметь строго типизированную структуру. Схема разделяет "знание о том, как использовать" от "самого процесса использования".

## Schema Structure
- `id`: string
- `name`: string
- `description`: string
- `executable`: string
- `parameters`: array of Parameter definitions
- `examples`: array of Example usage
- `confidence_score`: float

## Dependencies
- [ENG-0009](../entities/ENG-0009_confidence_calculator.md): confidence_calculator

## Related Decisions
- [ADR-0002](../decisions/ADR-0002_json_schema_for_skills.md): Использование JSON Schema в качестве базового формата.
