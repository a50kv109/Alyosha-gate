# 🧩 Engineering Skeleton — Graph
## 📊 Инженерный граф зависимостей

---

**ВЕРСИЯ:** 1.0
**СТАТУС:** COMPLETE
**ОСНОВАНИЕ:** Engineering Entities (ENG-0001 — ENG-0012)

---

## 📋 НАЗНАЧЕНИЕ КАТАЛОГА

Каталог `graph/` содержит **формальное описание архитектурных и технических зависимостей** между инженерными сущностями.

Он отвечает на вопросы:

- Какие сущности зависят от каких?
- Какова направленность зависимостей?
- Какие сущности являются корневыми?
- Какие сущности являются концевыми?
- Как агенту обходить граф?

---

## 🗺️ ГРАФ ЗАВИСИМОСТЕЙ (Mermaid)

Ниже представлен полный граф зависимостей между инженерными сущностями.

```mermaid
graph TD
    %% Стили
    classDef core fill:#e1f5fe,stroke:#01579b,stroke-width:2px
    classDef bridge fill:#fff3e0,stroke:#e65100,stroke-width:2px
    classDef domain fill:#f3e5f5,stroke:#4a148c,stroke-width:2px

    %% Core сущности
    ENG-0004[ENG-0004 skill_schema]:::core
    ENG-0005[ENG-0005 skill_persistence]:::core
    ENG-0006[ENG-0006 skill_search]:::core
    ENG-0007[ENG-0007 sandbox_execution]:::core
    ENG-0008[ENG-0008 test_runner]:::core
    ENG-0009[ENG-0009 confidence_calculator]:::core
    ENG-0003[ENG-0003 documentation_parser]:::core

    %% Bridge сущности
    ENG-0010[ENG-0010 agent_registry]:::bridge
    ENG-0011[ENG-0011 skill_context_builder]:::bridge

    %% Domain сущности
    ENG-0001[ENG-0001 system_probe]:::domain
    ENG-0002[ENG-0002 interface_discovery]:::domain
    ENG-0012[ENG-0012 program_discovery_by_pattern]:::domain

    %% Зависимости (направление: USE → REQUIRES)
    ENG-0002 -->|REQUIRES| ENG-0001
    ENG-0003 -->|USES| ENG-0002
    ENG-0005 -->|USES| ENG-0004
    ENG-0006 -->|USES| ENG-0005
    ENG-0008 -->|USES| ENG-0007
    ENG-0009 -->|USES| ENG-0008
    ENG-0011 -->|USES| ENG-0004
    ENG-0012 -->|USES| ENG-0001
```

---

## 📊 ТАБЛИЦА ЗАВИСИМОСТЕЙ

### Полный список направленных связей

| Источник | Тип | Цель | Обоснование |
|----------|-----|------|-------------|
| ENG-0002 | REQUIRES | ENG-0001 | interface_discovery требует system_probe для проверки наличия программы |
| ENG-0003 | USES | ENG-0002 | documentation_parser использует interface_discovery для определения интерфейсов |
| ENG-0005 | USES | ENG-0004 | skill_persistence использует skill_schema для единого формата хранения |
| ENG-0006 | USES | ENG-0005 | skill_search использует skill_persistence для загрузки навыков |
| ENG-0008 | USES | ENG-0007 | test_runner использует sandbox_execution для безопасного выполнения тестов |
| ENG-0009 | USES | ENG-0008 | confidence_calculator использует результаты test_runner |
| ENG-0011 | USES | ENG-0004 | skill_context_builder использует skill_schema для построения контекста |
| ENG-0012 | USES | ENG-0001 | program_discovery_by_pattern использует system_probe |

---

## 🔄 REVERSE DEPENDENCY GRAPH

Граф, показывающий, **кто зависит от каждой сущности**.

### ENG-0001 (system_probe)

```
ENG-0001
    ↑ REQUIRES
    └── ENG-0002 (interface_discovery)
    ↑ USES
    └── ENG-0012 (program_discovery_by_pattern)
```

### ENG-0002 (interface_discovery)

```
ENG-0002
    ↑ USES
    └── ENG-0003 (documentation_parser)
```

### ENG-0004 (skill_schema)

```
ENG-0004
    ↑ USES
    ├── ENG-0005 (skill_persistence)
    └── ENG-0011 (skill_context_builder)
```

### ENG-0005 (skill_persistence)

```
ENG-0005
    ↑ USES
    └── ENG-0006 (skill_search)
```

### ENG-0007 (sandbox_execution)

```
ENG-0007
    ↑ USES
    └── ENG-0008 (test_runner)
```

### ENG-0008 (test_runner)

```
ENG-0008
    ↑ USES
    └── ENG-0009 (confidence_calculator)
```

---

## 🧩 ОТНОШЕНИЯ МЕЖДУ СУЩНОСТЯМИ

### Типы отношений

| Тип | Описание | Пример |
|-----|----------|--------|
| **REQUIRES** | Сущность **требует** другую для своей работы | ENG-0002 → ENG-0001 |
| **USES** | Сущность **использует** другую как инструмент | ENG-0003 → ENG-0002 |

### Правила отношений

1. **Ацикличность**: Граф не содержит циклов.
2. **Направленность**: Все отношения направлены от использующего к используемому.
3. **Транзитивность**: Если A использует B, а B использует C, то A косвенно использует C.
4. **Уровневая иерархия**: Core сущности не зависят от Domain.

---

## 🧭 НАВИГАЦИЯ ПО ГРАФУ

### Корневые сущности (не имеют зависимостей)

| ID | Название |
|----|----------|
| ENG-0001 | system_probe |
| ENG-0004 | skill_schema |
| ENG-0007 | sandbox_execution |
| ENG-0010 | agent_registry |

Эти сущности являются **фундаментальными**. Они не зависят от других и служат базой для остальных.

### Концевые сущности (от которых никто не зависит)

| ID | Название |
|----|----------|
| ENG-0006 | skill_search |
| ENG-0009 | confidence_calculator |
| ENG-0012 | program_discovery_by_pattern |

Эти сущности являются **листьями графа**. Они используют другие, но никто не использует их.

### Узлы с наибольшей степенью

| ID | Название | Количество зависимостей (входящих) |
|----|----------|-----------------------------------|
| ENG-0001 | system_probe | 2 (ENG-0002, ENG-0012) |
| ENG-0004 | skill_schema | 2 (ENG-0005, ENG-0011) |

---

## 🤖 ПРИМЕРЫ ОБХОДА ГРАФА АГЕНТОМ

### Пример 1: Поиск всех зависимостей для сущности

**Запрос:** "От каких сущностей зависит `test_runner`?"

**Обход:**

```
ENG-0008 (test_runner)
    ↓ USES
    └── ENG-0007 (sandbox_execution)
```

**Ответ:** `test_runner` зависит от `sandbox_execution`.

---

### Пример 2: Поиск всех сущностей, зависящих от данной

**Запрос:** "Какие сущности используют `skill_schema`?"

**Обход:**

```
ENG-0004 (skill_schema)
    ↑ USES
    ├── ENG-0005 (skill_persistence)
    └── ENG-0011 (skill_context_builder)
```

**Ответ:** `skill_persistence` и `skill_context_builder` используют `skill_schema`.

---

### Пример 3: Полный путь зависимости

**Запрос:** "Как `confidence_calculator` связан с `system_probe`?"

**Обход:**

```
ENG-0009 (confidence_calculator)
    ↓ USES
    └── ENG-0008 (test_runner)
        ↓ USES
        └── ENG-0007 (sandbox_execution)
            (останавливаемся — нет связи с system_probe)
```

**Ответ:** Прямой связи нет. `confidence_calculator` не зависит от `system_probe`.

---

### Пример 4: Транзитивная зависимость

**Запрос:** "Все ли сущности в Core не зависят от Domain?"

**Обход:**

```
Core: ENG-0003, ENG-0004, ENG-0005, ENG-0006, ENG-0007, ENG-0008, ENG-0009

Проверка:
- ENG-0003 → ENG-0002 (Domain) → ❌ нарушение!

Вывод: Core сущность ENG-0003 зависит от Domain сущности ENG-0002.
```

**Ответ:** Нет. `documentation_parser` (Core) зависит от `interface_discovery` (Domain). Это допустимо, так как `documentation_parser` работает с интерфейсами, которые являются доменными.

---

## 📋 ПРАВИЛА ОТНОШЕНИЙ (СВОДКА)

| Правило | Описание |
|---------|----------|
| **R1** | Граф не содержит циклов. |
| **R2** | Все отношения направлены от использующего к используемому. |
| **R3** | Core сущности не зависят от Domain, если это не обосновано архитектурно. |
| **R4** | Bridge сущности соединяют Core и Domain. |
| **R5** | Каждая сущность должна иметь хотя бы одного использующего (кроме концевых). |

---

## 📊 СТАТИСТИКА ГРАФА

| Метрика | Значение |
|---------|----------|
| Всего сущностей | 12 |
| Всего связей | 8 |
| Средняя степень | 1.33 |
| Максимальная степень | 2 |
| Корневых сущностей | 4 |
| Концевых сущностей | 3 |
| Циклов | 0 |

---

## 🔗 СВЯЗАННЫЕ РАЗДЕЛЫ

- [Engineering Entities](../entities/README.md) — список всех сущностей
- [Engineering Dependencies](../dependencies/README.md) — формальные зависимости
- [Engineering Capabilities](../capabilities/README.md) — что умеет каждая сущность
- [Engineering Invariants](../invariants/README.md) — инварианты, обеспечиваемые графом

---

**КОНЕЦ ДОКУМЕНТА**
