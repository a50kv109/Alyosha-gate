# Engineering Repository: Mentor

Добро пожаловать в инженерный репозиторий проекта **Mentor**. 
Этот репозиторий представляет собой инженерную операционную среду, предназначенную для хранения, повторного использования и композиции инженерных знаний. Это не просто Wiki или база знаний, а фундаментальная инфраструктура, спроектированная как для людей, так и для ИИ-агентов.

## Terminology

**Engineering Constructor Primitive (ECP)** is the smallest reusable engineering building block used to construct Engineering Products.

An ECP is defined only by:
- purpose
- responsibility
- interfaces
- guarantees
- constraints

It is NOT defined by a specific application domain.

Engineering Skeleton is a library of Engineering Constructor Primitives (ECP).
Engineering Products are compositions built from ECPs.

## Repository Philosophy

This repository contains two different engineering layers.

They are intentionally separated because they solve different problems.

Engineering Skeleton
--------------------

Purpose:
Provide reusable Engineering Constructor Primitives (ECP).

Audience:
Engineers, AI agents and systems that need individual
engineering components.

Typical usage:
Reuse individual ECPs (ENG, INV, ADR, CAP)
inside another project.

Engineering Product
-------------------

Purpose:
Compose Engineering Constructor Primitives (ECP) into complete products.

Audience:
Users and agents looking for a ready engineering solution.

Typical usage:
Use a complete product (e.g. Mentor) rather than
assembling it from ECPs.

Relationship
------------

Engineering Product depends on Engineering Skeleton.

Engineering Skeleton does not depend on Engineering Product.

An agent may:

- reuse only Skeleton,
- use only a Product,
- build a new Product from Skeleton.

All three workflows are valid.

## Repository Entry Guide

Start here.

↓

Do you need a complete engineering solution?

        YES
         │
         ▼

Engineering Product

         │
         ▼

Choose a product
(Mentor, ...)

────────────────────────────

        NO
         │
         ▼

Do you need reusable Engineering Constructor Primitives (ECP)?

         │
         ▼

Engineering Skeleton

────────────────────────────

Need a completely new product?

         │
         ▼

Reuse Skeleton

↓

Build your own Engineering Product

## Repository Entry Rules

If your task is already solved by an Engineering Product,
start there.

Do not descend into Engineering Skeleton
unless you need:

• customization

• extension

• new product development

• reusable Engineering Constructor Primitives (ECP)

Otherwise stay at Product level.

## Структура репозитория

Репозиторий состоит из трех независимых уровней, образующих полноценную операционную среду:

1. **[Engineering Skeleton](./Engineering_Skeleton/)** — универсальная инженерная грамматика и Engineering Constructor Primitives (ECP). Знания ("Из чего строить"). Максимально независима от предметной области и готова к повторному использованию.
2. **[Engineering Product](./Engineering_Product/)** — конкретная реализация (Universal Mentor Module, BOOK-NAV и др.), сценарии использования и бизнес-логика. Сборка ("Что построено").
3. **[Engineering Workspace](./Engineering_Workspace/)** — единая рабочая среда. Интерфейсы, API, CLI. Среда обитания пользователя и агента ("Кто этим пользуется и как").

*Главный принцип: `Workspace → Product → Skeleton` (Рабочая среда запускает Продукты, Продукты собираются из ECPs Скелета. Зависимость направлена только вниз).*

## Документация и Навигация

Для ознакомления с правилами и архитектурой репозитория, изучите следующие документы:
- 🏛️ **[ARCHITECTURE](./docs/ARCHITECTURE.md)** — Подробное описание структуры и назначения каждого каталога.
- 🤖 **[AGENT PROTOCOL](./docs/AGENT_PROTOCOL.md)** — Протокол взаимодействия для автономных инженерных ИИ-агентов.
- 📏 **[ENGINEERING STANDARDS](./docs/ENGINEERING_STANDARDS.md)** — Стандарты именования, система стабильных ID и оформление Markdown.
- 🤝 **[CONTRIBUTING](./docs/CONTRIBUTING.md)** — Правила внесения изменений, "Конституция проекта".
- 🗺️ **[NAVIGATION](./docs/NAVIGATION.md)** — Глобальная карта навигации и перекрёстных ссылок.
