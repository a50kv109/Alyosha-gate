# Карта Навигации (NAVIGATION)

## Индексы Engineering Skeleton

Здесь собраны ссылки на основные индексные файлы каждой подсистемы:

- 🧱 **[Entities Index](../Engineering_Skeleton/entities/README.md)** — Реестр Engineering Constructor Primitives (ECP).
- 🕸️ **[Graph Index](../Engineering_Skeleton/graph/README.md)** — Архитектурный граф и структурные связи.
- 💡 **[Rationale Index](../Engineering_Skeleton/rationale/README.md)** — Мотивация и инженерные проблемы.
- 🔒 **[Invariants Index](../Engineering_Skeleton/invariants/README.md)** — Фундаментальные ограничения.
- 🔄 **[Lifecycle Index](../Engineering_Skeleton/lifecycle/README.md)** — Состояния и триггеры.
- ⚖️ **[Decisions Index (ADR)](../Engineering_Skeleton/decisions/README.md)** — Архитектурные решения.
- 🎬 **[Interactions Index](../Engineering_Skeleton/interactions/README.md)** — Сценарии и потоки данных.
- 🧩 **[Classification Index](../Engineering_Skeleton/classification/README.md)** — Граница Core / Domain.
- 🔗 **[Dependencies Index](../Engineering_Skeleton/dependencies/README.md)** — Технические зависимости сущностей.
- ⚙️ **[Capabilities Index](../Engineering_Skeleton/capabilities/README.md)** — Спецификация способностей.

## Индексы Engineering Product

- 🚀 **[Universal Mentor Module](../Engineering_Product/Mentor/README.md)** — Главный индекс конечного продукта.

## Индексы Engineering Workspace

- 💻 **[Workspace Home](../Engineering_Workspace/README.md)** — Главная точка входа в рабочую среду.
- 🤖 **[Agent API](../Engineering_Workspace/agent_api/README.md)** — Протоколы и точки доступа для агентов.
- 🖥️ **[GUI IDE](../Engineering_Workspace/gui/README.md)** — Графический интерфейс.
- ⌨️ **[CLI Tools](../Engineering_Workspace/cli/README.md)** — Инструменты командной строки.
