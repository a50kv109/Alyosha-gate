with open('Engineering_Skeleton/decisions/ADR-0001_system_probe_separation.md', 'r') as f:
    content = f.read()

content = content.replace("Purpose:**\n...", "Purpose:**\nАгенту нужно знать, какие программы установлены. Выделение проверки в отдельный сервис позволяет избежать дублирования кода.")

with open('Engineering_Skeleton/decisions/ADR-0001_system_probe_separation.md', 'w') as f:
    f.write(content)
