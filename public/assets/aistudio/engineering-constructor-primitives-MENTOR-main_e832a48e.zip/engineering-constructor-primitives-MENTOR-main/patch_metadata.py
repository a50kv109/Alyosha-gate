import os
import re
import glob

def patch_file(filepath):
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Check if already patched
    if "--------------------------------------------------" in content and "**Type:**" in content:
        return False
        
    filename = os.path.basename(filepath)
    is_eng = filename.startswith("ENG-")
    is_inv = filename.startswith("INV-")
    is_adr = filename.startswith("ADR-")
    
    if not (is_eng or is_inv or is_adr):
        return False
        
    # Extract ID and Name from filename or content
    match = re.search(r"((?:ENG|INV|ADR)-\d{4}):?\s*(.+?)(?:\n|##)", content)
    if not match:
        print(f"Skipping {filepath}, couldn't parse title.")
        return False
        
    identifier = match.group(1).strip()
    name = match.group(2).strip()
    # Remove emoji if present
    name = re.sub(r'^[🧩\s]+', '', name)
    name = re.sub(r'\*\*', '', name)
    
    # Try to extract Purpose from "## 📋 ОПИСАНИЕ" or similar
    purpose = "..."
    desc_match = re.search(r"## 📋 ОПИСАНИЕ\s*(.+?)\s*---", content, re.DOTALL)
    if not desc_match:
        desc_match = re.search(r"## 📋 КОНТЕКСТ\s*(.+?)\s*---", content, re.DOTALL)
        
    if desc_match:
        purpose = desc_match.group(1).strip().replace('\n', ' ')
        # Truncate if too long
        if len(purpose) > 200:
            purpose = purpose[:197] + "..."

    new_metadata = f"""# {identifier}: {name}

--------------------------------------------------

**Type:**
Engineering Constructor Primitive (ECP)

**Name:**
{name}

**Identifier:**
{identifier}

**Purpose:**
{purpose}

--------------------------------------------------

"""
    # Replace the top part
    # We want to replace everything from the start up to the second "---" or the first "## 📋"
    
    top_pattern = re.compile(r"^#.*?---.*?---", re.DOTALL)
    new_content = top_pattern.sub(new_metadata.strip(), content, count=1)
    
    if new_content == content:
        # Fallback if there are no "---"
        top_pattern2 = re.compile(r"^#.*?## 📊[^\n]+\n+", re.DOTALL)
        new_content = top_pattern2.sub(new_metadata.strip(), content, count=1)

    if new_content == content:
        print(f"Failed to replace top block for {filepath}")
        return False

    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(new_content)
        
    return True

files = glob.glob('Engineering_Skeleton/entities/*.md') + \
        glob.glob('Engineering_Skeleton/invariants/*.md') + \
        glob.glob('Engineering_Skeleton/decisions/*.md')

for f in files:
    if patch_file(f):
        print(f"Patched metadata in {f}")

