with open('Engineering_Workspace/README.md', 'r') as f:
    content = f.read()
content = content.replace("исследует** примитивы", "исследует** ECPs")
with open('Engineering_Workspace/README.md', 'w') as f:
    f.write(content)

with open('Engineering_Workspace/cli/README.md', 'r') as f:
    content = f.read()
content = content.replace("продукта из примитивов", "продукта из ECPs")
with open('Engineering_Workspace/cli/README.md', 'w') as f:
    f.write(content)
