/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Cpu } from 'lucide-react';

export default function App() {
  return (
    <div className="bg-[#0B0F13] text-[#E0E6ED] h-screen w-full flex flex-col font-sans overflow-hidden">
      {/* Top Navigation / Header */}
      <header className="h-16 bg-[#131921] border-b border-[#2D3748] flex items-center justify-between px-6 shrink-0">
        <div className="flex items-center space-x-4">
          <div className="bg-blue-600 p-2 rounded-sm">
            <Cpu className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-lg font-bold tracking-tight uppercase leading-none">Engineering Repository Generator</h1>
            <p className="text-[10px] font-mono text-blue-400 opacity-80 mt-1 uppercase tracking-widest">AAM-V2_ARTSYBASHEV_UA_KHARKIV_AIANALYSIS</p>
          </div>
        </div>
        <div className="flex space-x-6 items-center text-xs font-mono">
          <div className="flex items-center space-x-2">
            <span className="w-2 h-2 rounded-full bg-green-500 shadow-[0_0_8px_#10b981]"></span>
            <span className="uppercase">Status: Initialized</span>
          </div>
          <div className="flex items-center space-x-2 border border-blue-500/30 px-3 py-1 rounded bg-blue-500/5">
            <span className="text-blue-400 uppercase">Mode: Preservation</span>
          </div>
          <div className="text-gray-500">Exp: Mentor</div>
        </div>
      </header>

      {/* Main Content Layout */}
      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar Navigation */}
        <nav className="w-64 bg-[#0F141B] border-r border-[#2D3748] flex flex-col shrink-0">
          <div className="p-4">
            <p className="text-[10px] text-gray-500 uppercase font-bold tracking-widest mb-4">Knowledge Layers</p>
            <div className="space-y-1">
              <a href="#" className="flex items-center space-x-3 px-3 py-2 bg-blue-600/10 text-blue-400 border-l-2 border-blue-600 rounded-r-sm transition-all">
                <span className="font-mono text-xs">00</span>
                <span className="text-sm font-medium">Constitution</span>
              </a>
              <a href="#" className="flex items-center space-x-3 px-3 py-2 hover:bg-white/5 text-gray-400 rounded-r-sm transition-all">
                <span className="font-mono text-xs">01</span>
                <span className="text-sm font-medium">Engineering Skeleton</span>
              </a>
              <a href="#" className="flex items-center space-x-3 px-3 py-2 hover:bg-white/5 text-gray-400 rounded-r-sm transition-all ml-4">
                <span className="font-mono text-xs">-</span>
                <span className="text-sm">Entities</span>
              </a>
              <a href="#" className="flex items-center space-x-3 px-3 py-2 hover:bg-white/5 text-gray-400 rounded-r-sm transition-all ml-4">
                <span className="font-mono text-xs">-</span>
                <span className="text-sm">Architecture Graph</span>
              </a>
              <a href="#" className="flex items-center space-x-3 px-3 py-2 hover:bg-white/5 text-gray-400 rounded-r-sm transition-all ml-4">
                <span className="font-mono text-xs">-</span>
                <span className="text-sm">Invariants</span>
              </a>
              <a href="#" className="flex items-center space-x-3 px-3 py-2 hover:bg-white/5 text-gray-400 rounded-r-sm transition-all ml-4">
                <span className="font-mono text-xs">-</span>
                <span className="text-sm">Rationale</span>
              </a>
              <a href="#" className="flex items-center space-x-3 px-3 py-2 hover:bg-white/5 text-gray-400 rounded-r-sm transition-all">
                <span className="font-mono text-xs">02</span>
                <span className="text-sm font-medium">Engineering Product</span>
              </a>
              <a href="#" className="flex items-center space-x-3 px-3 py-2 hover:bg-white/5 text-gray-400 rounded-r-sm transition-all ml-4">
                <span className="font-mono text-xs">-</span>
                <span className="text-sm">Universal Mentor</span>
              </a>
              <a href="#" className="flex items-center space-x-3 px-3 py-2 hover:bg-white/5 text-gray-400 rounded-r-sm transition-all">
                <span className="font-mono text-xs">03</span>
                <span className="text-sm font-medium">Engineering Workspace</span>
              </a>
              <a href="#" className="flex items-center space-x-3 px-3 py-2 hover:bg-white/5 text-gray-400 rounded-r-sm transition-all ml-4">
                <span className="font-mono text-xs">-</span>
                <span className="text-sm">Agent API</span>
              </a>
              <a href="#" className="flex items-center space-x-3 px-3 py-2 hover:bg-white/5 text-gray-400 rounded-r-sm transition-all ml-4">
                <span className="font-mono text-xs">-</span>
                <span className="text-sm">CLI Tools</span>
              </a>
            </div>
          </div>
          <div className="mt-auto p-4 border-t border-[#2D3748]">
            <div className="flex items-center justify-between text-[10px] text-gray-500 font-mono">
              <span>GUARDIAN_MODE</span>
              <span className="text-green-500">ACTIVE</span>
            </div>
          </div>
        </nav>

        {/* Main Workspace */}
        <main className="flex-1 flex flex-col bg-[#0B0F13] p-6 space-y-6 overflow-hidden">
          {/* Dashboard Stats */}
          <div className="grid grid-cols-4 gap-4">
            <div className="bg-[#131921] border border-[#2D3748] p-4 rounded">
              <p className="text-[10px] text-gray-500 uppercase font-mono mb-1">Entities</p>
              <div className="text-2xl font-bold font-mono">0012</div>
            </div>
            <div className="bg-[#131921] border border-[#2D3748] p-4 rounded">
              <p className="text-[10px] text-gray-500 uppercase font-mono mb-1">Invariants</p>
              <div className="text-2xl font-bold font-mono">0004</div>
            </div>
            <div className="bg-[#131921] border border-[#2D3748] p-4 rounded">
              <p className="text-[10px] text-gray-500 uppercase font-mono mb-1">Decisions (ADR)</p>
              <div className="text-2xl font-bold font-mono">0008</div>
            </div>
            <div className="bg-[#131921] border border-[#2D3748] p-4 rounded">
              <p className="text-[10px] text-gray-500 uppercase font-mono mb-1">Active Agents</p>
              <div className="text-2xl font-bold font-mono text-blue-400">0002</div>
            </div>
          </div>

          {/* Active View: Entity Inspector */}
          <div className="flex-1 flex space-x-6 min-h-0">
            {/* Entity List */}
            <div className="w-1/3 bg-[#131921] border border-[#2D3748] rounded flex flex-col">
              <div className="p-3 border-b border-[#2D3748] bg-[#1A212B]">
                <span className="text-xs font-bold uppercase tracking-wider">Skeleton Entities</span>
              </div>
              <div className="flex-1 overflow-y-auto p-2 space-y-2">
                <div className="p-2 bg-blue-600/20 border border-blue-500/50 rounded flex justify-between items-center cursor-pointer">
                  <span className="text-xs font-mono text-blue-400">ENG-0001</span>
                  <span className="text-xs font-medium truncate ml-2">system_probe</span>
                </div>
                <div className="p-2 hover:bg-white/5 border border-transparent rounded flex justify-between items-center cursor-pointer group">
                  <span className="text-xs font-mono text-gray-500 group-hover:text-gray-300">ENG-0002</span>
                  <span className="text-xs font-medium truncate ml-2 text-gray-400 group-hover:text-gray-200">interface_discovery</span>
                </div>
                <div className="p-2 hover:bg-white/5 border border-transparent rounded flex justify-between items-center cursor-pointer group">
                  <span className="text-xs font-mono text-gray-500 group-hover:text-gray-300">ENG-0003</span>
                  <span className="text-xs font-medium truncate ml-2 text-gray-400 group-hover:text-gray-200">documentation_parser</span>
                </div>
                <div className="p-2 hover:bg-white/5 border border-transparent rounded flex justify-between items-center cursor-pointer group">
                  <span className="text-xs font-mono text-gray-500 group-hover:text-gray-300">ENG-0004</span>
                  <span className="text-xs font-medium truncate ml-2 text-gray-400 group-hover:text-gray-200">skill_schema</span>
                </div>
              </div>
            </div>

            {/* Inspector Details */}
            <div className="flex-1 bg-[#131921] border border-[#2D3748] rounded flex flex-col">
              <div className="p-4 border-b border-[#2D3748] flex justify-between items-center">
                <div className="flex items-center space-x-3">
                  <span className="px-2 py-1 bg-[#2D3748] text-[10px] font-mono rounded">ENG-0001</span>
                  <h2 className="text-lg font-bold">system_probe</h2>
                </div>
                <span className="text-[10px] font-mono px-2 py-1 bg-green-500/10 text-green-500 border border-green-500/30 rounded uppercase tracking-tighter">Status: Fact</span>
              </div>
              <div className="p-6 space-y-6 overflow-y-auto">
                <section>
                  <h3 className="text-[10px] text-gray-500 uppercase font-bold tracking-widest mb-2">Purpose & Rationale</h3>
                  <p className="text-sm text-gray-300 leading-relaxed">
                    Centralized service for verifying the presence of programs within the system path. Ensures the agent does not attempt to execute non-existent binaries, preventing runtime errors.
                  </p>
                </section>
                <div className="grid grid-cols-2 gap-6">
                  <section>
                    <h3 className="text-[10px] text-gray-500 uppercase font-bold tracking-widest mb-2">Dependencies</h3>
                    <ul className="space-y-1 font-mono text-xs text-blue-400">
                      <li>None (Root Infrastructure)</li>
                    </ul>
                  </section>
                  <section>
                    <h3 className="text-[10px] text-gray-500 uppercase font-bold tracking-widest mb-2">Invariants</h3>
                    <ul className="space-y-1 font-mono text-xs text-orange-400">
                      <li>INV-0001: discovery_before_use</li>
                    </ul>
                  </section>
                </div>
                <section className="mt-auto bg-[#0B0F13] p-4 rounded border border-[#2D3748] font-mono text-[10px]">
                  <h3 className="text-gray-500 mb-2 uppercase">Source Metadata</h3>
                  <pre className="text-blue-500">
{`source:
  name: "Mentor Chat"
  block: "Block 01"
  revision: 2`}
                  </pre>
                </section>
              </div>
            </div>
          </div>
        </main>
      </div>

      {/* Footer Status Bar */}
      <footer className="h-8 bg-[#131921] border-t border-[#2D3748] flex items-center px-4 shrink-0 justify-between text-[10px] font-mono">
        <div className="flex space-x-4">
          <span className="text-gray-500 uppercase">Engine: Mentor_OS</span>
          <span className="text-gray-500 uppercase">Branch: Kharkiv_AIAnalysis</span>
        </div>
        <div className="flex space-x-4">
          <span className="text-blue-500 uppercase">Repository initialized successfully</span>
          <span className="text-gray-600 tracking-tighter">2024.10.12.AAM</span>
        </div>
      </footer>
    </div>
  );
}
