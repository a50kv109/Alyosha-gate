import os
import re

def process_file(filepath):
    with open(filepath, 'r') as f:
        content = f.read()

    # Find the title
    title_match = re.search(r'^#\s*([A-Z]+-\d+):\s*(.+)$', content, re.MULTILINE)
    if not title_match:
        return False
    identifier = title_match.group(1).strip()
    name = title_match.group(2).strip()

    # Find the description to use as purpose
    desc_match = re.search(r'## Description\s*(.*?)(?=\n## |\Z)', content, re.MULTILINE | re.DOTALL)
    purpose = desc_match.group(1).strip().replace('\n', ' ') if desc_match else "..."

    # Replace Metadata
    metadata_block = f"""--------------------------------------------------

**Type:**
Engineering Constructor Primitive (ECP)

**Name:**
{name}

**Identifier:**
{identifier}

**Purpose:**
{purpose}

--------------------------------------------------
"""
    
    # Check if we already have Metadata
    if '## Metadata' in content:
        # replace the existing metadata section
        content = re.sub(r'## Metadata\s*.*?(?=\n## |\Z)', metadata_block, content, flags=re.MULTILINE | re.DOTALL)
    else:
        # Replace the generated block if it exists
        if '--------------------------------------------------' in content:
            content = re.sub(r'-{50}\n\n\*\*Type:\*\*.*?-{50}\n', metadata_block, content, flags=re.MULTILINE | re.DOTALL)
        else:
            # Insert after title
            content = re.sub(r'(^# .+?\n)', r'\1\n' + metadata_block + '\n', content, count=1)
        
    with open(filepath, 'w') as f:
        f.write(content)
    return True

for root, dirs, files in os.walk('Engineering_Skeleton'):
    for file in files:
        if file.endswith('.md') and (file.startswith('ENG-') or file.startswith('INV-') or file.startswith('ADR-')):
            filepath = os.path.join(root, file)
            process_file(filepath)
            print(f'Processed {filepath}')

