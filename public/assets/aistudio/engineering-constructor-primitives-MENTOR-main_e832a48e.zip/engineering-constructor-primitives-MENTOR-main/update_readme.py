import re

with open('Engineering_Product/Mentor/README.md', 'r') as f:
    content = f.read()

metadata_block = """--------------------------------------------------

**Type:**
Engineering Product

**Built From:**
Engineering Constructor Primitives (ECP)

**Name:**
Mentor

**Purpose:**
Accelerate learning by composing and applying capabilities provided by Engineering Skeleton.

--------------------------------------------------
"""
if '**Type:**' not in content:
    content = re.sub(r'(^# .+?\n)', r'\1\n' + metadata_block + '\n', content, count=1)
    with open('Engineering_Product/Mentor/README.md', 'w') as f:
        f.write(content)

with open('Engineering_Skeleton/README.md', 'r') as f:
    content = f.read()
    
metadata_block_skeleton = """--------------------------------------------------

**Type:**
Engineering Constructor Primitive (ECP) Library

**Name:**
Engineering Skeleton

**Purpose:**
Provide reusable engineering constructor primitives for building Engineering Products.

--------------------------------------------------
"""
if '**Type:**' not in content:
    content = re.sub(r'(^# .+?\n)', r'\1\n' + metadata_block_skeleton + '\n', content, count=1)
    content = content.replace("фундаментальные строительные блоки (инженерные примитивы)", "Engineering Constructor Primitives (ECP)")
    content = content.replace("инженерных примитивов", "Engineering Constructor Primitives (ECP)")
    with open('Engineering_Skeleton/README.md', 'w') as f:
        f.write(content)

